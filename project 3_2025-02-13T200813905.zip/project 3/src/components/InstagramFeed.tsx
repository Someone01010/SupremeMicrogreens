import BeholdWidget from "@behold/react";

const InstagramFeed = () => {
  return (
    <div className="w-full">
      <BeholdWidget feedId="PQHAeI6FNqbuPnY5m5K8" />
    </div>
  );
};

export default InstagramFeed;