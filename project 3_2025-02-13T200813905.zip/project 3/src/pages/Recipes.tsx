import InstagramFeed from '../components/InstagramFeed';
import Footer from '../components/Footer';

const recipes = [
  {
    title: "Peashoot Pesto",
    image: "https://images.unsplash.com/photo-1611712142269-12b7433e28e9?auto=format&fit=crop&q=80",
    description: "A fresh and vibrant pesto made with tender pea shoots, perfect for pasta or as a spread.",
  },
  {
    title: "Spicy Microgreen Thins",
    image: "https://images.unsplash.com/photo-1603903631918-a6a92fb6ac49?auto=format&fit=crop&q=80",
    description: "Crispy appetizers topped with our signature spicy microgreen blend.",
  },
  {
    title: "Microgreens Pho",
    image: "https://images.unsplash.com/photo-1547928576-a4a33237cbc3?auto=format&fit=crop&q=80",
    description: "Traditional Vietnamese soup elevated with fresh microgreens.",
  }
];

const Recipes = () => {
  return (
    <div className="bg-white min-h-screen">
      {/* Hero Section */}
      <div className="relative pt-20">
        <div className="bg-[#2B432B] relative overflow-hidden">
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1515278734953-5bbe533e3b5e?auto=format&fit=crop&q=80')] opacity-20 bg-cover bg-center" />
          <div className="max-w-7xl mx-auto px-4 py-24 relative">
            <h1 
              className="text-6xl font-shabby text-white text-center mb-4"
              data-aos="fade-up"
              data-aos-duration="1000"
            >
              The Recipe Book
            </h1>
            <div className="absolute right-0 bottom-0 transform translate-x-1/4">
              <svg className="w-32 h-32 text-white/10" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* Recipe Cards */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {recipes.map((recipe, index) => (
            <div 
              key={index}
              className="bg-white rounded-lg shadow-lg overflow-hidden transform hover:-translate-y-1 transition-all duration-300"
              data-aos="fade-up"
              data-aos-delay={index * 100}
            >
              <div className="aspect-w-1 aspect-h-1 relative">
                <img
                  src={recipe.image}
                  alt={recipe.title}
                  className="w-full h-64 object-cover"
                />
              </div>
              <div className="p-6 bg-white">
                <h3 className="text-xl font-semibold mb-2">{recipe.title}</h3>
                <p className="text-gray-600">{recipe.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Social Section */}
      <div className="bg-[#2B432B] py-16">
        <div className="max-w-7xl mx-auto px-4">
          <h2 
            className="text-5xl font-shabby text-white text-center mb-12"
            data-aos="fade-up"
          >
            Let's get social!
          </h2>
          <InstagramFeed />
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Recipes;